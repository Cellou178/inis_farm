# 🐔 INIS Smart Farm

**Plateforme avicole intelligente — Sénégal**

## Accès rapide
👉 **[Ouvrir l'application](https://votre-username.github.io/inis-farm)**

## Installation sur mobile
1. Ouvrir le lien ci-dessus dans **Chrome**
2. Menu ⋮ → **"Ajouter à l'écran d'accueil"**
3. L'app s'installe comme une vraie application 📱

## Fonctionnalités
- 📊 Suivi cycles avicoles (C1/C2/C3)
- 🤖 IA prédictive croissance
- 💰 Gestion financière complète
- 🛒 Marketplace Afrique de l'Ouest
- 💳 Paiement Wave / Orange Money
- 🌡️ Capteurs IoT temps réel
- 👥 Multi-fermes & multi-utilisateurs
- 🔐 Sécurité avancée

## Connexion Super Admin
- **Email** : celloudiallo286@gmail.com
- **Mot de passe** : inis2024

## Contact
📱 +221 777 221 19 31  
✉️ celloudiallo286@gmail.com  
📍 Niarry Tally, Dakar, Sénégal

---
*© 2026 INIS Smart Farm — Made with ❤️ pour les éleveurs d'Afrique*
