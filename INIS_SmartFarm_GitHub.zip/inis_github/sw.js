// INIS Smart Farm — Service Worker
// Permet l'utilisation hors connexion (mode rural)

const CACHE_NAME = 'inis-farm-v1';
const FILES_TO_CACHE = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js'
];

// Installation — mettre en cache les fichiers essentiels
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      console.log('[SW] Mise en cache des fichiers...');
      return cache.addAll(FILES_TO_CACHE.filter(f => !f.startsWith('http') || navigator.onLine));
    })
  );
  self.skipWaiting();
});

// Activation — nettoyer les anciens caches
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(keyList) {
      return Promise.all(keyList.map(function(key) {
        if(key !== CACHE_NAME) {
          console.log('[SW] Suppression ancien cache:', key);
          return caches.delete(key);
        }
      }));
    })
  );
  self.clients.claim();
});

// Fetch — servir depuis le cache si hors ligne
self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request).then(function(response) {
      if(response) return response; // Depuis le cache
      return fetch(event.request).then(function(response) {
        // Mettre en cache la nouvelle réponse
        if(!response || response.status !== 200) return response;
        var responseToCache = response.clone();
        caches.open(CACHE_NAME).then(function(cache) {
          cache.put(event.request, responseToCache);
        });
        return response;
      }).catch(function() {
        // Hors ligne et pas en cache
        if(event.request.destination === 'document') {
          return caches.match('./index.html');
        }
      });
    })
  );
});

// Message pour forcer la mise à jour
self.addEventListener('message', function(event) {
  if(event.data === 'skipWaiting') self.skipWaiting();
});
